

# Build Instruction


```
mvn clean package
and build the instruction .
```

# Deploy instruction

Deploy ```target/WebApp.war``` on Tomcat properly for better experience.

